(function () {
    'use strict';
 
    myModule
        .controller('RegisterController', RegisterController);
 
    RegisterController.$inject = ['UserService', '$location', '$rootScope'];
    function RegisterController(UserService, $location, $rootScope) {
        var vm = this;
 
        vm.register = register;
 
        function register() {
            vm.dataLoading = true;
            UserService.Create(vm.user)
                .then(function (response) {
                    if (response.success) {
                        //FlashService.Success('Registration successful', true);
                    	alert('Registration Successful!');
                        $location.path('/login');
                    } else {
                        //FlashService.Error(response.message);
                    	alert(response.message);
                        vm.dataLoading = false;
                    }
                });
        }
    }
 
})();